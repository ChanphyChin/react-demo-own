import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Button } from 'antd';
import { DatePicker } from 'antd';

class HomeContainer extends Component {
  click(){
    this.props.history.push('/details')
  }
  render() {
    return (
      <div className="home">
        这是首页
        <br />
        <Link to={`/details`} className="nav">
        跳转到商品详情
        </Link>
        <br />
        <Button type="primary">Primary</Button>
        <DatePicker type="primary">Primary</DatePicker>
      </div>
    );
  }
}

export default HomeContainer;
