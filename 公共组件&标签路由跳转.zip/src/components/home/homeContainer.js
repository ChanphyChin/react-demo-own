import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class HomeContainer extends Component {
  click(){
    this.props.history.push('/details')
  }
  render() {
    return (
      <div className="home" onClick={()=>{this.click()}}>
        这是首页
        <br />
        <Link to={`/details`} className="nav">
        跳转到商品详情
        </Link>
      </div>
    );
  }
}

export default HomeContainer;
