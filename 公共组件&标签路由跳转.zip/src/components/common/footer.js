import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <div className="footer">
        这是公共底部
      </div>
    );
  }
}

export default Header;
