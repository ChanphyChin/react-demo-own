import React, { Component } from 'react';
import { Router , Route , hashHistory , Link , history} from 'react-router';
//引入antd栅格布局
import { Row, Col } from 'antd';
class Header extends Component {
  constructor(props) {
      super(props);
      //构造函数用法
      //常用来绑定自定义函数，切记不要在这里或者组件的任何位置setState，state全部在reducer初始化，相信对开发的后期很有帮助
      //例子：this.myfunction = this.myfunction.bind(this)
      this.handleClick = this.handleClick.bind(this)
  }
  componentDidMount(){
  }
  handleClick(){
    // alert(`触发`)
    this.props.history.push('/details')
  }
  render() {
    return (
      <div>
    <Row>
      <Col span={12}>col-12</Col>
      <Col span={12}>col-12</Col>
    </Row>
    <Row>
      <Col span={8}>col-8</Col>
      <Col span={8}>col-8</Col>
      <Col span={8}>col-8</Col>
    </Row>
    <Row>
      <Col span={6}>col-6</Col>
      <Col span={6}>col-6</Col>
      <Col span={6}>col-6</Col>
      <Col span={6}>col-6</Col>
    </Row>
  </div>
    );
  }
}

export default Header;
