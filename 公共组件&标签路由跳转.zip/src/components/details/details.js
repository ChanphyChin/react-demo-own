import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Detail extends Component {
  render() {
    return (
      <div className="detail">
        这是商品详情
        <br />
        <Link to={`/`} className="nav">
        返回首页
        </Link>
      </div>
    );
  }
}

export default Detail;
